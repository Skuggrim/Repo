# -*- coding: utf-8 -*-
"""
vjackson.py - Directory Navigation Module

This module handles the addon's navigation structure and directory listings:
- Main index (country/region selection)
- Category navigation
- Refresh handlers for countries and channels
- Helper functions for creating directory items

The module acts as a router for the addon's menu structure,
delegating to vjlive.py for actual channel listing and playback.
"""

import sys

import xbmcplugin
from xbmcgui import ListItem

# =============================================================================
# IMPORTS
# =============================================================================
try:
    from resources.lib import utils
except ImportError:
    from lib import utils

# =============================================================================
# INFOTAGGER SUPPORT
# =============================================================================
try:
    from infotagger.listitem import ListItemInfoTag
    TAGGER_AVAILABLE = True
except ImportError:
    TAGGER_AVAILABLE = False


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def _set_listitem_info(listitem, info_labels):
    """
    Set info labels on a ListItem with tagger support.
    """
    if TAGGER_AVAILABLE:
        info_tag = ListItemInfoTag(listitem, 'video')
        info_tag.set_info(info_labels)
    else:
        listitem.setInfo("Video", info_labels)


# =============================================================================
# NAVIGATION HANDLERS
# =============================================================================

def _index(params):
    """
    Display the main index - list of available countries/regions.
    Red 'Refresh Country List' entry at the top.
    """
    utils.set_content("files")
    
    from resources.lib import vjlive
    
    # --- Red Refresh entry at top ---
    addDir2("[COLOR red]Refresh Country List[/COLOR]", "refresh_countries", isFolder=True)
    
    countries = vjlive.get_available_countries()
    
    settings_ctx = ("Settings", f"RunPlugin({sys.argv[0]}?action=settings)")
    
    for country in countries:
        addDir2(country, "channelsbycategory", 
                context=[settings_ctx],
                group=country)
    
    utils.end()


def _livecategories(params):
    """
    Display live categories (backward compatibility).
    """
    _index(params)


def _channelsbycategory(params):
    """
    Display channels for a specific country/category.
    """
    group = params.get("group", "Germany")
    utils.set_content("files")
    
    from resources.lib import vjlive
    vjlive.channels_by_group(group)


def _refresh_countries(params):
    """
    Force-refresh the country list, show progress, and cleanly reload the main menu.
    """
    import xbmc
    import xbmcgui
    from resources.lib import vjlive
    
    progress = xbmcgui.DialogProgress()
    progress.create('VavooTV', 'Refreshing country list...')
    progress.update(30)
    
    vjlive.refresh_country_cache()
    
    progress.update(70, 'Fetching fresh list...')
    vjlive.get_available_countries(use_cache=False)
    
    progress.update(100)
    progress.close()
    
    utils.notify("Country list refreshed")
    utils.end(succeeded=False)
    # Go back to parent (the real main menu), then force it to refresh
    xbmc.executebuiltin("Action(ParentDir)")
    xbmc.sleep(300)
    xbmc.executebuiltin("Container.Refresh")


def _refresh_channels(params):
    """
    Force-refresh the channel list for a specific group, show progress, and reload.
    """
    import xbmc
    import xbmcgui
    from resources.lib import vjlive
    
    group = params.get("group", "Germany")
    
    progress = xbmcgui.DialogProgress()
    progress.create('VavooTV', f'Refreshing channels for {group}...')
    progress.update(30)
    
    vjlive.refresh_group_cache(group)
    
    progress.update(70, 'Fetching fresh list...')
    vjlive.getchannels_by_group(group)
    
    progress.update(100)
    progress.close()
    
    utils.notify(f"{group} channels refreshed")
    utils.end(succeeded=False)
    # Go back to parent (the channel list), then force it to refresh
    xbmc.executebuiltin("Action(ParentDir)")
    xbmc.sleep(300)
    xbmc.executebuiltin("Container.Refresh")


def _refresh(params):
    """
    Force-refresh all channel data (clears caches). Legacy action.
    """
    from resources.lib import vjlive
    vjlive.refresh_channels()
    utils.notify("Channel list refreshed")
    import xbmc
    xbmc.executebuiltin("Container.Refresh")


# =============================================================================
# DIRECTORY ITEM CREATION
# =============================================================================

def addDir(name, params, isFolder=True, context=None):
    """
    Add a directory item to the current listing.
    Uses Kodi's default folder icon.
    """
    listitem = ListItem(name)
    
    if context is None:
        context = []
    
    if not context:
        context.append(("Settings", f"RunPlugin({sys.argv[0]}?action=settings)"))
    
    listitem.addContextMenuItems(context)
    
    info_labels = {"title": name, "plot": " "}
    _set_listitem_info(listitem, info_labels)
    
    utils.add(params, listitem, isFolder)


def addDir2(name, action, context=None, isFolder=True, **params):
    """
    Convenience wrapper for addDir with automatic action parameter.
    
    Example:
        addDir2("Germany", "channelsbycategory", group="Germany")
    """
    params["action"] = action
    addDir(name, params, isFolder, context or [])
